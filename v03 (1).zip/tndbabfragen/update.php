<?php
include "../db/dbverbindung.php";
if(isset($_POST['aktualisieren'])){
    //Speichern wir die Eingaben in paar Variablen
    $idnummer = htmlspecialchars($_POST['id']);
    $vorname = htmlspecialchars ($_POST['vorname']);
    $nachname = htmlspecialchars($_POST['nachname']);
    $email = htmlspecialchars ($_POST['email']); 
    //SQL Abfrage
    $sql = "Update teilnehmer SET vorname=?, nachname=?, email=? WHERE tID=?";
    //prepare statement
    $cmd= $verbindung->prepare($sql);
    //Abfrage ausführen
    $cmd->execute([$vorname, $nachname, $email, $idnummer]);

    //Umleitung
    header("location:../index.php");
    exit;
}

?>